﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.IO;
using System.Globalization;
using HtmlAgilityPack;
using CsvHelper;
using System.Linq;

namespace Web_Scrapper
{
    class Program
    {
        static void Main(string[] args)
        {

            string url = "https://books.toscrape.com/index.html";
            var links = Getbooklinks(url);

            List<Book> books = Getbooks(links);
            export(books);

            //Console.Write(doc.DocumentNode.InnerHtml);
        }


        static List<string> Getbooklinks(String url)
        {
            var links = new List<string>();
            HtmlDocument doc = GetDocument(url);
            HtmlNodeCollection linknodes = doc.DocumentNode.SelectNodes("//h3/a");
            var baseUri = new Uri(url);

            foreach (var node in linknodes)
            {
                string href = node.Attributes["href"].Value;
                links.Add(new Uri(baseUri, href).AbsoluteUri);
            }

            do
            {
                var next = doc.DocumentNode.SelectSingleNode("//*[@class=\"next\"]/a").Attributes["href"].Value;
                url = new Uri(baseUri, next).AbsoluteUri;
                doc = GetDocument(url);

                // linknodes.Append(doc.DocumentNode.SelectNodes("//h3/a"));
                foreach (var node in linknodes)
                {
                    var link = node.Attributes["href"].Value;
                    links.Add(new Uri(baseUri, link).AbsoluteUri);
                }
            } while (string.IsNullOrWhiteSpace(url));

            return (links);
        }


        static HtmlDocument GetDocument(string url)
        {
            var web = new HtmlWeb();
            HtmlDocument doc = web.Load(url);
            return doc;

        }

        static List<Book> Getbooks(List<string> links)
        {
            var books = new List<Book>();
            foreach (var link in links)
            {
                var doc = GetDocument(link);
                var book = new Book();
                book.Title = doc.DocumentNode.SelectSingleNode("//h1").InnerText;
                var xpath = "//div[contains(@class,\"product_main\")]/p[@class=\"price_color\"]";
                var price_raw = doc.DocumentNode.SelectSingleNode(xpath).InnerText;
                book.Price = Extractprice(price_raw);
                books.Add(book);
            }
            return books;

        }

        static double Extractprice(string price_raw)
        {
            double retVal = 0;

            try
            {
                var reg = new Regex(@"[\d\.,]+", RegexOptions.Compiled);
                var m = reg.Match(price_raw);
                if (!m.Success && !double.TryParse(m.Value, out double val))
                    return 0;
                retVal = Convert.ToDouble(m.Value);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return retVal;
        }

        private static void export(List<Book> books)
        {
            using (var writer = new StreamWriter("M:\\Milin\\Projects\\Piyush\\Books\\Book1.csv"))
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                csv.WriteRecords(books);
            }
        }
    }
}
